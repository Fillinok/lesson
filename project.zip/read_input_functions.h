#pragma once
#include <string>
#include <iostream>
std::string ReadLine();
int ReadLineWithNumber();